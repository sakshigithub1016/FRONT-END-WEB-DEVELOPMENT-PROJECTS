var swiper = new Swiper('.swiper-container', {
  loop: true,
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
  },
  effect: 'fade', // Adding a fade effect for smooth transitions
  on: {
    slideChangeTransitionStart: function() {
      animateText();
    },
  },
});

function animateText() {
  var slides = document.querySelectorAll('.swiper-slide');
  slides.forEach(function(slide) {
    var animatedTextElements = slide.querySelectorAll('.animated-text');
    animatedTextElements.forEach(function(element) {
      element.classList.remove('fadeInUp');
      void element.offsetWidth; // Trigger reflow
      element.classList.add('fadeInUp');
    });
  });
}

animateText(); // Initial animation
