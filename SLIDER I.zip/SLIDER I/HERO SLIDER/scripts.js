var swiper = new Swiper('.swiper-container', {
    loop: true,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    effect: 'cube',
    cubeEffect: {
        slideShadows: false,
        shadow: true,
        shadowOffset: 20,
        shadowScale: 0.94,
    },
    on: {
        slideChangeTransitionStart: function () {
            animateText();
        },
    },
});

function animateText() {
    var activeSlide = document.querySelector('.swiper-slide-active');
    var animatedTextElements = activeSlide.querySelectorAll('.animated-text');
    animatedTextElements.forEach(function(element) {
        element.classList.add('slideInUp');
    });
}
