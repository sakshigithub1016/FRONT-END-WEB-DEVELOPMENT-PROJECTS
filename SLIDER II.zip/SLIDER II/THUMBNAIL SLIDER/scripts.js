var swiperThumbs = new Swiper('.swiper-container-thumbs', {
  slidesPerView: 3,
  spaceBetween: 10,
  freeMode: true,
  watchSlidesVisibility: true,
  watchSlidesProgress: true
});

var swiperMain = new Swiper('.main-slider', {
  thumbs: {
      swiper: swiperThumbs
  },
  navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev'
  },
  pagination: {
      el: '.swiper-pagination',
      clickable: true
  },
  autoplay: {
      delay: 3000
  },
  loop: true,
  effect: 'fade',
  fadeEffect: {
      crossFade: true
  }
});
