var map;
var marker;

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: -34.397, lng: 150.644},
        zoom: 8,
        mapTypeId: google.maps.MapTypeId.ROADMAP // Default map type
    });

    var zoomInButton = document.getElementById('zoomInButton');
    var zoomOutButton = document.getElementById('zoomOutButton');
    var toggleSatelliteButton = document.getElementById('toggleSatelliteButton');
    var addMarkerButton = document.getElementById('addMarkerButton');

    zoomInButton.addEventListener('click', function() {
        map.setZoom(map.getZoom() + 1);
    });

    zoomOutButton.addEventListener('click', function() {
        map.setZoom(map.getZoom() - 1);
    });

    toggleSatelliteButton.addEventListener('click', function() {
        toggleSatelliteView();
    });

    addMarkerButton.addEventListener('click', function() {
        addMarker();
    });
}

function toggleSatelliteView() {
    var currentMapTypeId = map.getMapTypeId();
    if (currentMapTypeId === google.maps.MapTypeId.ROADMAP) {
        map.setMapTypeId(google.maps.MapTypeId.SATELLITE);
    } else {
        map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
    }
}

function addMarker() {
    if (!marker) {
        marker = new google.maps.Marker({
            position: map.getCenter(),
            map: map
        });
    } else {
        marker.setMap(null);
        marker = null;
    }
}
