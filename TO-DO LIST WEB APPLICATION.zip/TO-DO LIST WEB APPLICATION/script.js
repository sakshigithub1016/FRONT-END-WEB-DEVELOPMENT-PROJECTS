let taskCount = {
    total: 0,
    completed: 0
};

function addTask() {
    var taskInput = document.getElementById("taskInput");
    var dueDateInput = document.getElementById("dueDateInput");
    var priorityInput = document.getElementById("priorityInput");
    var typeInput = document.getElementById("typeInput");
    var taskList = document.getElementById("taskList");

    if (taskInput.value === '') {
        alert("Please enter a task.");
        return;
    }

    var li = document.createElement("li");

    var taskText = `${taskInput.value} (Due: ${dueDateInput.value}, Priority: ${priorityInput.value}, Type: ${typeInput.value})`;
    li.textContent = taskText;

    var completeButton = document.createElement("button");
    completeButton.textContent = "Complete";
    completeButton.className = "complete-button";
    completeButton.onclick = function () {
        li.classList.add("completed");
        updateTaskCount(true);
        updateAchievements();
        taskList.removeChild(li);
    };

    var deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.className = "delete-button";
    deleteButton.onclick = function () {
        updateTaskCount(false);
        taskList.removeChild(li);
    };

    li.appendChild(completeButton);
    li.appendChild(deleteButton);
    taskList.appendChild(li);

    taskInput.value = '';
    dueDateInput.value = '';
    priorityInput.value = 'Medium';
    typeInput.value = 'Work';

    updateTaskCount(false);
}

function updateTaskCount(isCompleted) {
    taskCount.total++;
    if (isCompleted) {
        taskCount.completed++;
    }
    document.getElementById('completedTasks').textContent = taskCount.completed;
    document.getElementById('remainingTasks').textContent = taskCount.total - taskCount.completed;

    var completedBar = document.getElementById('completedBar');
    var remainingBar = document.getElementById('remainingBar');

    completedBar.style.width = (taskCount.completed / taskCount.total) * 100 + '%';
    remainingBar.style.width = ((taskCount.total - taskCount.completed) / taskCount.total) * 100 + '%';
}

function updateAchievements() {
    var achievementsDiv = document.getElementById('achievements');
    achievementsDiv.innerHTML = '';

    if (taskCount.completed > 0 && taskCount.completed === taskCount.total) {
        var badge = document.createElement('div');
        badge.className = 'badge';
        badge.innerHTML = '🏆 All tasks completed on time!';
        achievementsDiv.appendChild(badge);
    }
}

function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
}

let slideIndex = 0;
function showSlides() {
    let slides = document.getElementsByClassName("slider-image");
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {
        slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 3000);
}

showSlides();
